//Real-Time Clock
const clock = document.getElementById('clock');
function tick() {
  if (!clock) return;
  const now = new Date();
  clock.textContent = now.toLocaleTimeString([], { hour12: false });
}
tick();
setInterval(tick, 1000);


// Mobile Sidebar & Menu Controls
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');
const menuButton = document.getElementById('menuButton');

function toggleMenu(open) {
  if (sidebar) sidebar.classList.toggle('open', open);
  if (overlay) overlay.classList.toggle('show', open);
}

if (menuButton) menuButton.addEventListener('click', () => toggleMenu(true));
if (overlay) overlay.addEventListener('click', () => toggleMenu(false));

document.querySelectorAll('.sidebar a').forEach(a => {
  a.addEventListener('click', () => toggleMenu(false));
});

// Water Level / Chart Time Range Selector
document.querySelectorAll('.range button').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.range button').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  });
});


// Satellite Live Map Initialization
let mapInstance = null;

function initSatelliteMap() {
  if (mapInstance) return;

  const lat = 16.9292;
  const lng = 97.3686;
  mapInstance = L.map('map').setView([lat, lng], 12);
  L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    maxZoom: 19,
    attribution: 'Tiles &copy; Esri &mdash; Earthstar Geographics'
  }).addTo(mapInstance);

  // High-Contrast Overlay Labels (Towns & Roads)
  L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager_only_labels/{z}/{x}/{y}{r}.png', {
    maxZoom: 19
  }).addTo(mapInstance);

  // Fetch telemetry markers from your Backend API
  fetch('/api/v1/live-sensors')
    .then(response => response.json())
    .then(sensors => {
      sensors.forEach(sensor => {
        const color = sensor.level === 'Critical' ? '#e63946' : '#0787e8';
        L.circleMarker([sensor.lat, sensor.lng], {
          color: color,
          fillColor: color,
          fillOpacity: 0.8,
          radius: 8
        }).addTo(mapInstance).bindPopup(`<b>${sensor.name}</b><br>Level: ${sensor.level}`);
      });
    })
    .catch(() => {
      // Fallback pins for testing
      L.marker([lat, lng]).addTo(mapInstance)
        .bindPopup('<b>Thaton Center</b><br>Water level: 1.2m (Normal)')
        .openPopup();

      L.circle([16.95, 97.38], {
        color: '#cb202b',
        fillColor: '#cb202b',
        fillOpacity: 0.35,
        radius: 1200
      }).addTo(mapInstance).bindPopup('<b>Gort Village</b><br>Critical Water Level Alert');
    });
}

// ==========================================
// 5. Layer Switching (Home View <-> Live Map)
// ==========================================
function switchLayer(targetHash) {
  const homeView = document.getElementById('home-view');
  const mapView = document.getElementById('map-view');
  const allNavLinks = document.querySelectorAll('.side-nav a, .bottom-nav a');

  // Standardize target hash
  const activeHash = (targetHash === '#map') ? '#map' : '#home';

  // 1. Update navigation active states
  allNavLinks.forEach(link => {
    if (link.getAttribute('href') === activeHash) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });

  // 2. Handle Layer Display
  if (activeHash === '#map') {
    if (homeView) homeView.style.display = 'none';

    // Set to 'flex' so vertical stacked alerts & layout render correctly
    if (mapView) mapView.style.display = 'flex';

    // Initialize satellite map
    initSatelliteMap();

    // Recalculate map container size & re-render Lucide icons
    setTimeout(() => {
      if (typeof mapInstance !== 'undefined' && mapInstance) {
        mapInstance.invalidateSize();
      }
      if (window.lucide) {
        lucide.createIcons();
      }
    }, 150);

  } else {
    if (mapView) mapView.style.display = 'none';
    if (homeView) homeView.style.display = 'block';
  }

  // 3. Close mobile menu if open
  toggleMenu(false);
}

// ==========================================
// 6. Navigation Event Listeners
// ==========================================

// Click handlers for nav links
document.querySelectorAll('a[href="#home"], a[href="#map"], a[href="#safety"]').forEach(anchor => {
  anchor.addEventListener('click', (e) => {
    e.preventDefault();
    const hash = anchor.getAttribute('href');
    window.location.hash = hash;
    switchLayer(hash);
  });
});

// Watch URL changes (Browser Back/Forward buttons)
window.addEventListener('hashchange', () => {
  switchLayer(window.location.hash);
});

// Run automatically on initial page load
document.addEventListener('DOMContentLoaded', () => {
  const initialHash = window.location.hash || '#home';
  switchLayer(initialHash);
});
